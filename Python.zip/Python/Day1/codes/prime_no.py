# prime no : number which is divisible 
# ONLY by itself and 1
## if a number is divisible by any other no
# other than 1 and itself, then it is not a prime
# divisible --> when remainder is zero
num = int(input("Enter a number"))
n=2
while n < num:
    if num%n == 0:
        print("Not a prime")
        break
    n=n+1
else:
    print("prime")
        