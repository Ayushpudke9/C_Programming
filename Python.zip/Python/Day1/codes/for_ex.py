# take 5 numbers and print them
for i in range(5):
    num = int(input("Enter next number"))
    print(num)
