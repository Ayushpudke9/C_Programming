# Menu driven program
# Step1 : show a menu ( options)
# Step2: Ask your his / her choice
#Step 3: use match and case to execute only 
# given option
# WAP for a restro 
print("Menu : 1. Misal 2. Pizza 3. Momo 4. Noodles 5. Dosa")
choice = int(input("Enter your choice"))
print(choice)
match(choice):
    case 1:
        print("Misal is selected! Rs 100")
    case 2:
        print("Pizza is selected! Rs 120")
    case 3:
        print("Momo is selected! Rs 60")
    case 4:
        print("noodles is selected! Rs 80")
    case 5:
        print("dosa is selected! Rs 110")

    case _: # default case
        print("Item not available!")


