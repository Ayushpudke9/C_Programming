class car:
    def __init__(self):#method
        self.company="toyota"#variable :: data members
        self.model="creta"#variable ::data members
    def display_info(self):#method
        print(self.company,self.model)

car_obj1 = car()
car_obj1.display_info()

class pen:
    def __init__(self):#method
        self.ink_color=input("Enter ink color of pen")
        self.company = input("Enter company of pen")
    def display_info(self):
        print(self.ink_color,self.company)
    def write(self):
        print("Pen is writing in color=",
              self.ink_color)

pen1 = pen() # pen1 is object of class pen
pen1.write()


class DITISS_FEB2025:
    def __init__(self,student_name_list,roll_nos):
        self.student_name_list = student_name_list
        self.roll_nos = roll_nos
    def display_info(self):
        print("All student names of DITISS FEB 2025")
        print(self.student_name_list)
        print("All student roll nos of DITISS FEB 2025")
        print(self.roll_nos)
    def study(self):
        print("All DITISS FEB 2025 students are studying")

a206 = DITISS_FEB2025(["chirag","piyush","harshada"],
                      ["22","24","13"])
a206.study()   


##############################################
### Instance variables and class variable
class car:
    no_of_wheels=4#class variable
    def __init__(self):#method
        self.company="toyota"#instance variable :: data members
        self.model="creta"#instance variable ::data members
    def display_info(self):#method
        print(self.company,self.model)
        print(car.no_of_wheels)#class variable

car_obj1 = car()
car_obj1.display_info()

##############################################
### method types 
### instance method, class method, static method

class Employee:
    company_name="Google"#class variable
    def __init__(self,name):#instance method
        self.name = name # instance variable
    def display(self):#instance method
        print(self.name, self.company_name)
    @classmethod
    def display_company(cls):#class method
        print(cls.company_name)
    @staticmethod
    def display_static():#static method
        print(Employee.company_name)

emp1 = Employee("shreyas")
emp2=Employee("yashashri")
#instance method calling
emp1.display()
#Employee.display()#Error
#class method calling
Employee.display_company()
emp1.display_company()
#static method calling
Employee.display_static()
emp1.display_static()
        
############################################
"""
# ERROR in the code
class id_card:
    def __init__(): #ERROR in the code
        print("Object is getting initialized")

id1 = id_card()
#PVM calls __new__() to allocate memory
# then __new__() calls __init__() to initialize
"""

# Correct code for __init__
class id_card:
    def __init__(self): #first para is always self
        print("Object is getting initialized")

id1 = id_card()
#PVM calls __new__() to allocate memory
# then __new__() calls __init__() to initialize

#######################################
# OVERLOADING a method 
# in one class two methods with same name
class trial:
    def method1(self):
        print("method1 with self")
    def method1(seld,v1):#this overwrites previous method1
        print("method1 with self and v1")

t1 = trial()
#t1.method1() # ERROR 
t1.method1(10) # NO ERROR 


