class Employee:
    company_name="Amazon"
    def __init__(self):
        self.empid=int(input("Enter empid"))
        self.name=input("Enter name")
        self.__salary=int(input("Enter salary"))
    
    def display_id(self):
        print(self.empid,self.name,self.company_name)
    
    def get_salary(self):
        print("salary is ", self.__salary)

emp1= Employee()
emp1.display_id()
emp1.get_salary()
# check NAME mangling
#print(emp1.__salary)# Error
print(emp1._Employee__salary)