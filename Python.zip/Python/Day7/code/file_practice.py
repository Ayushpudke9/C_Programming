# create a new file --> open file in write mode
fp = open("new_file.txt","w")
fp.close()

# Write into the file 
# we can use write mode(w) or append mode(a)
fp = open("new_file.txt","w")
# write a string in the file
fp.write("Hello DITISS students!!!!")
#close the file
fp.close()

# Read the contents of the file
# we use read mode(r) to read the file
fp = open("new_file.txt","r")
# read ALL contents of file in single string
contents = fp.read()
# get list of lines from contents
lines_list = contents.split("\n")
#close the file
fp.close()