def rec_hello(count):
    print("Hello")
    if count <3:# breaking condition
        rec_hello(count+1)
    return
def fact(n):
    if n > 0:#breaking condition
        return n*fact(n-1)
    return 1

rec_hello(1)
print(fact(5))
