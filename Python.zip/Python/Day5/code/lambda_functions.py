lambda x : print(x)
# lambda keyword
# arguments : x
# : (colon)
# one line open
# THERE is no return statement
print("print 10 using lambda func")
(lambda x : print(x))(10)
print("Add two nos")
res = (lambda a,b: a+b)(10,20)
print(res)
print("Add two nos")
def add(a,b):
    return a+b
# give a name to lambda function
func2 = (lambda x : print(x))
func2(100)

# Advanced examples ::::
# sort values in dictionary 
# using lambda function

