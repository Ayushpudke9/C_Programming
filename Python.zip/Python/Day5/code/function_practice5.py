"""
create a function to take dictionary 
as input print all keys of dictionary
print all values of dictionary
"""
def func1(d):
    print("keys are ")
    for k in d.keys():
        print(k)
    print("values are ")
    for v in d.values():
        print(v)

d1 = {1:100,"hh":67, (1,2,3):55}
print(d1)
func1(d1)