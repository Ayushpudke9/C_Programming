def add1(a,b):# parameters a and b
    """add with parameters a and b"""
    c= a+b
    print(c)
    # return None

def sub(a,b):
    """substraction"""
    c= a-b
    print(c)
    # return None

def add(): # no parameters
    """Simple addition of 10 and 20 """
    c = 10+20
    print(c)
    return  # return None
print(add.__doc__)
print(print.__doc__)