## NAMED ARGUMENT / NAMED PARAMETER
def func1(*,name,surname):
    """ name and surname are 
    keyword arguments
    also known as named arguments"""
    print(name, surname)

#func1("suraj","rungta")# ERROR
func1(name="suraj",
      surname="rungta") #No ERROR
# sequence is not compulsory
func1(surname="rungta",
      name="suraj") #No ERROR 

####################################
## OPTIONAL ARGUMENT / OPTIONAL PARAMETER
#null --> None
def get_qualification(m_10, m_12=0,
                      m_deploma=0):
    """
    m_10 :: compulsory
    m_12 :: optional / default
    m_deploma:: optional / default
    """
    print(m_10, m_12,m_deploma)

get_qualification(55,m_12=80)
get_qualification(55,m_deploma=90)
###################################
## Standard arguments
def add(a,b):
    """
    a and b both are compulsory
    a and b are standard arguments
    """
    print(a+b)
#add(10) ## ERROR
add(10,20)
add(a=23,b=34)
add(b=100,a=200)