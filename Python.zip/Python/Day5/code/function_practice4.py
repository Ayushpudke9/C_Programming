"""
WAP to have maxmin function to 
return max and min from a list
"""
def maxmin(l1):
    max_val = max(l1)
    min_val = min(l1)
    return max_val, min_val

l = [1,2,3,56,78,9,33]
res = maxmin(l)
print(res)

res = print("Hello")
print(res) # None


def check_prime(no):
    n=2
    while n < no: # for n in range(2,no):
        if no%n == 0:
            #print("NOT prime")
            return "NOT prime"
            break
        n = n+1
    else:
        #print("Prime")
        return "Prime"
res = check_prime(10)
print(res)

def modify_list(l1):
    l1.append(10)
    return 

l = [1,2,3]
print(l) #[1,2,3]
modify_list(l)
print(l)#[1,2,3,10]
