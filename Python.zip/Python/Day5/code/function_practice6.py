"""
write a function
take a string as input
return all special characters 
in that string
"""
def find_special_char(s1):
    sp_chars=""
    for ch in s1:
        if (ch.isalpha() == False) and (ch.isdigit() == False):
            sp_chars = sp_chars+ch
    return sp_chars
s="!@#$%^&*()><?:asdjaskldj"
sp =find_special_char(s)
print(sp)

"""
WA function to take a string 
as parameter. Print its alternate 
characters starting from 2nd character
"""
def alt_char(s):
    print(s[::2])
    for i in range(0,len(s),2):
        print(s[i])
    for i in range(1,len(s),2):
        print(s[i])