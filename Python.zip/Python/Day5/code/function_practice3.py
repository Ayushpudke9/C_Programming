"""
WAP function to multiply all odd numbers
from 1 to 100 and print the result
"""
def mult_1(start, end):
    result = 1
    for num in range(start,end):
        if num%2 != 0: # select only odd no
            result = result * num
    print(result)

mult_1(1,100)

def factorial(n): # n=-5
    fact=1
    for num in range(1,n+1):
        fact = fact *num 
    print(fact)

n = int(input("Enter a number"))
factorial(n)