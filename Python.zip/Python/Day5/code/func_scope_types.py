def func1(v1,v2):
    print(v1,v2) #local variables v1&v2
    print(a) # allowed --> a is global
    #print(out) #ERROR --> out is local

def outer():
    out=10#local variable to outer
    def inner():
        print("in inner")
        print(out)
        #out variable is non-local
    return inner # allowed!!

a=10 #global variable a

def modify():
    global g1 # compulsory to modify g1
    print(g1) # allowed
    g1 = g1 + 10 # modification 
            #directly NOT allowed

g1=100 #global g1
modify()

