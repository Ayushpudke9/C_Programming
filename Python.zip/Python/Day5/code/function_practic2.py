def my_function():
    print("This is my function")

my_function()
fun1 = my_function # copy by assignment
fun1()

l = [ fun1, my_function]
print(l)