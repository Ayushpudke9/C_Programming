import re

s1 ="DITISS students are wonderful"
s2 ="Today is a wonderful day"

regex1="[TID]"
print(re.match(regex1,s1))#D
print(re.match(regex1,s2))#T
print(re.search(regex1,s1))#D
print(re.search(regex1,s2))#T
print(re.findall(regex1,s1))#['D', 'I', 'T', 'I']
print(re.findall(regex1,s2))#['T']


regex1="s"
print(re.match(regex1,s1))#None
print(re.match(regex1,s2))#None
print(re.search(regex1,s1))#s
print(re.search(regex1,s2))#s
print(re.findall(regex1,s1))#['s','s']
print(re.findall(regex1,s2))#['s']

# find numbers in a given string
s1= "My mobile no is 9890717784"
s2="My emp id is 4"
s3="2025 is a beautiful year"

regex1="[0-9]+"
print(re.match(regex1,s1))#None
print(re.match(regex1,s2))#None
print(re.match(regex1,s3))#2025
print(re.search(regex1,s1))#989071884
print(re.search(regex1,s2))#4
print(re.search(regex1,s3))#2025
print(re.findall(regex1,s1))#['9890717884']
print(re.findall(regex1,s2))#['4']
print(re.findall(regex1,s3))#['2025']

# match the email id
s1="shantanuspathak@gmail.com"
s2="989071884@khjkhjkh.in"
s3="!!!@ghghjg.com"

regex1="[a-zA-Z0-9]+@[a-zA-Z]+\.[a-zA-Z]+"
print(re.match(regex1,s1))#shantanuspathak@gmail.com
print(re.match(regex1,s2))#989071884@khjkhjkh.in
print(re.match(regex1,s3))#None
print(re.search(regex1,s1))#shantanuspathak@gmail.com
print(re.search(regex1,s2))#989071884@khjkhjkh.in
print(re.search(regex1,s3))#None
print(re.findall(regex1,s1))#['shantanuspathak@gmail.com']
print(re.findall(regex1,s2))#['989071884@khjkhjkh.in']
print(re.findall(regex1,s3))#[]