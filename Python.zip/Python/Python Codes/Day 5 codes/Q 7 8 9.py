#Q WA function to take a dictionary as parameter. Print value of key "name" if key "rollno" is 
#having value 100.

student1 = {"name": "abc", "rollno": 100, "grade": "A"}

def name(d):
    if d.get("rollno") == 100:
        print(d("name"))
name(student1)
    

#Q WA function to take list of strings as parameter and 
#print all strings which have character 's' 2 times

str1 = ["hi" , "hello" , "welcome" , "bye"] 
def string(str1):  
    for s in str1:
        if s.count('s') == 2:
            print(str1)

string(str1)

#Q WA function to take list of dictionaries. Print all dictionaries which contain key "id".

dict_list = [{"name": "abc", "id": 102, "city": "New York"},
             {"name": "abc", "age": 25}
            ]
def dict(dict_list):
    for d in dict_list:
        if "id" in d:
            print(d)

dict(dict_list)