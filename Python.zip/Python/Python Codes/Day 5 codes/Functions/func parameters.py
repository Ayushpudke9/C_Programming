#Name Arguments

def func1(*,name,surname):
    """name and surname are keyword arguments also as named arguments"""
    print(name,surname)
func1(name = "Yashashri" , surname = "Gawande")
func1(surname = "Yashashri" , name = "Gawande")    #sequence doesn't matter

#func1("yashashri" , "gawande")    #error

#Optional Arguments

def get_qualification(m_10 , m_12=0 , m_diploma=0):
    """m_10 is compulsory but 
       m_12 is optional/default
       m_diploma is optional/default"""
    print(m_10 , m_12 , m_diploma)

#in python there is None no null
get_qualification(55,m_12=None)        
get_qualification(55,m_diploma=90)


#standard arguments

def add(a,b):
    """a and b are standard arguments"""
    print(a+b)
add(10,20)
add(a=23,b=34)
add(b=100,a=200)

#write a function take a string as input return all special characters in string 
def str():
    str = "#%&*" 
    
print()


