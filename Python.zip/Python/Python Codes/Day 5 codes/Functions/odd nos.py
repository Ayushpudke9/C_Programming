#wap function to multiply all odd numbers from 1 to 100 and print the result

def mul1():
    a = 1
    for i in range(1,100):
        if i%2 != 0:
           a *= i
    print("multiplication is :" ,a)
mul1()


#wap to calculate factorial of number 

#def factorial(n):
#    fact = 1
#    for num in range(1,n+1):
#        fact = fact  * num
#    print(fact)

#n=int(input("enter a number :"))
#factorial(n)

#wap to have max function to retuen max and min from a list
def maxmin(l1):
    max_val = max(l1)
    min_val = min(l1)
    return max_val, min_val

l = [1, 2, 3, 56, 78, 9, 33]
print(maxmin(l))


#wap to check given no is prime no or not return not prime

def check_prime(no):
#num = int(input("enter a number :"))
    n = 2
    while n < no:
        if no%n == 0:
            #print("non - prime")
            return "Non prime"
            #break
        n = n+1
    else:
    #print("prime")
        return "prime"
    
res = check_prime(10)
print(res)

    


           




    

