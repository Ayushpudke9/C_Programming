def rec_hello(count):
    print("Hello")
    if count <3:   #breaking condition
        rec_hello(count+1)
    return

def fact(n):
    if n > 0:
        return n*fact(n-1)
    return 1
rec_hello(1)
print(fact(5))

#write a function to take a string and print only vowels from the string

def str():
    s1 = "hello"
    for char in s1:
        if char in "aeiou":
            print(char)
    
str()


#write a function to take dictionary as input print all key of dictionary and all the values in the dictionary

def dict1(d):
    print("keys are")
    for k in d.keys():
        print(k)
    print("values are")
    for v in d.values():
        print(v)

d1 = {1:100, "hh":67 , (1,2,3):55}
print(d1)
dict1(d1)
    
#write a function to take string as input and print all special characters


def str(s):
    special_char = ""

    for char in s:
        if not char.isalnum() and char != " ":
            special_chars += char

    print(special_char)




