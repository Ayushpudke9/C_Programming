#syntax

def my_function():    #function definition
    print("This is my function")
    return
my_function()  #function call



def add():  #no parameters
    a = 10     #addition of two nos
    b = 20
    add = a+b
    print("addition is :", add)
    return
add()



def my_function():    #function definition
    print("This is my function")
my_function()  #function call
fun1 = my_function    #copy by assignment
fun1()

l = [fun1 , my_function]
print(l)


