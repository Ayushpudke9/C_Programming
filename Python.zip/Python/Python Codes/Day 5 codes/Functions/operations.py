def add(a,b):             #addition
    c = a + b
    print("addition is :", c)
    #return none

def sub(a,b):             #subtraction
    c = a - b
    print("subtraction is :", c)
    #return none

def mul(a,b):             #multiplication
    c = a * b
    print("multiplication is :", c)
    #return none

def div(a,b):             #division
    c = a / b
    print("Division is :", c)
    #return none

add(8,2)
sub(8,2)
mul(8,2)
div(8,2)



def add():
    """simple addition of 10 and 20"""
    c=10+20
    print(c)
    return
print(add.__doc__)
print(add.__doc__)
