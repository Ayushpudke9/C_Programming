#Q WA function to take a number as parameter and print True if given number is even else print False
def even(num):
    print(num % 2 == 0)

even(10)  
even(7) 


#Q 2 WA function to take list as parameter and print all numbers of given list which are divisible by 11

num_list = [22, 45, 67, 44, 78, 88]
def divisible(num):
    for n in num:
        if n % 11 == 0:
            print(n)
divisible(num_list)

#Q 3 waf to print string palindrome

s = "madam"
if (s==(s[::-1])):
    print("palindrome")
else:
    print("not palindrome")






    