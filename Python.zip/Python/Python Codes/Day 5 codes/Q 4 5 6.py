#WA function to check if number is prime or not. Return True if number is prime and false 
#if number not prime.

def prime(n):
    if n <= 1:
        return False
    
    for i in range(2, 1):
        if n % i == 0:
            return False
    return True


#Q WA function to take a string as parameter. Print its alternate characters starting from 2nd character

def chars(s):
    print(s[1::2])

chars("abcdef") 

#Q WA function to take dictionary as parameter. Print all keys of the dictionary

dict1 = {"name": "Hina", "age": 25, "city": "India"}
def dict(d):
    for key in d.keys():
        print(key)

dict(dict1)