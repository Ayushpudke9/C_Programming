#wap take name of user as input print every character of name separately

#name = input("enter your name")
#print(name)
#for char in name:
#    print(char)

s1 = "IAIAIAIAIAIA"
print(s1.count("I"))
print(s1.count("A"))
print(s1.count("AI"))
print(s1.count("IA"))


s1 = "AAAA"
#how many times with overlap :: 3
#how many times without overlap :: 2
print(s1.count("AA"))

s1 = "IAIA"
print(s1.find("IA"))  #0
print(s1.rfind("IA"))  #2

#wap take name of user as input print name in lowercase

s1 = "ABCD"
print("Lower Case", s1.lower())
print("Upper Case", s1.upper())


#split function
s1 = "Today is wonderful day"
print(s1.split(" ")) #return lost of string


#split function
#spli returns list
ipadd = "172.168.1.127"
print(ipadd.split(".")) #return lost of string

#ip 192.168.1.2  split in subnets

ipadd = "192.168.1.2"
print(ipadd.split("."))

log_msg= "error|192.56.78.89|4567"
print(log_msg.split("|"))

#join function
#take list of string and convert in one string

list_s1 = ["ditiss", "students", "are", "wonderful"]
s1 = " ".join(list_s1)
print(s1)
s1 = "|".join(list_s1)
print(s1)
s1 = "*".join(list_s1)
print(s1)


#concat two strings
s1 = "iacsd"
s2 = "abc" 
print(s1 + s2)
print(s1 + " " + s2)