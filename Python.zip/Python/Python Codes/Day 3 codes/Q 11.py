#11. Given a paragraph count number of words, sentences. Every sentence ends with either . or ? or !
#Print Count of how many normal sentences ending with . , how many interrogative sentences ( ending
#with ?) and how many exclamatory sentences ( ending with !).
#Ex.
#Input : “I am at CDAC. What about you? I am surprised by current weather!”
##Normal sentence : 1
#Interrogative: 1
#Exclamatory : 1

s = input("Enter a paragraph: ")

word_count = 0
sentence_count = 0

word_count = len(s.split())
print(word_count)

normal_count = ""
interrogative_count = ""
exclamatory_count = ""

for idx in range(len(s)):
    if s[idx] in ".":
        normal_count = normal_count + s[idx]
    elif s[idx] in "?":
        interrogative_count = interrogative_count + s[idx]
    elif s[idx] in "!":
        exclamatory_count = exclamatory_count + s[idx]
    

print(len(normal_count))
print(len(interrogative_count))
print(len(exclamatory_count))












    

