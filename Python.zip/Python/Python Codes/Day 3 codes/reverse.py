#5. Given a two Python list. Iterate both lists simultaneously such that list1 should 
# display item in original order and list2 in reverse order. It should work for any two lists.


l1 = [10, 20, 30, 40]
l2 = [100, 200, 300, 400]

l3=l2[::-1]
#l2.reverse()
for idx in range(len(l1)):
        print(l1[idx], l3[idx])
        
    



