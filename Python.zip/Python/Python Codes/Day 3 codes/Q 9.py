#9. Find all mobile number mentioned in given paragraph of text
#Mobile number is always a 10 digit number no spaces no special characters
#Ex. Input= “this is a good number 9089786756 and 8900000000 is a desired number”
#Expected output: 9089786756 , 8900000000

paragraph = input("Enter a paragraph: ")

words = paragraph.split()

mobile_numbers = []

for word in words:
    if word.isdigit() and len(word) == 10:  # Check if it's a number and exactly 10 digits
        mobile_numbers.append(word)

print("Mobile numbers:", ", ".join(mobile_numbers))
