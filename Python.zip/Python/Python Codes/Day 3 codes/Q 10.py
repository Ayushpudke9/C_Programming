#10. Count occurrence of spaces, and special characters in given string

#Input: 

#Expected output :
#Spaces: 1
#Special characters: 2

s = input("Enter a string: ") 

space_count = 0
special_char_count = 0

for char in s:
    if char == " ":
        space_count += 1
    elif not char.isalnum():  # Check if the character is NOT a letter or number
        special_char_count += 1


print(space_count)
print(special_char_count)