#5. create a third-string made of the first char of s1 then the last char of s2, Next, the second char
#of s1 and second last char of s2, and so on. Any leftover chars go at the end of the result.
#Expected Output:
#AzbycX

s1 = "Abc"
s2 = "Xyz"
middle_1 = len(s1)//2
middle_2 = len(s2)//2
print(s1[0] + s2[2] + s1[middle_2] + s2[middle_1] + s1[2] + s2[0])