#consonants
s1 = "ahrekdinwo"
s1 = s1.lower()
for char in s1:
    if char not in "aeiou":
       print(char)
    
#vowels
s1 = "ahrekdinwo"
s1 = s1.lower()
for char in s1:
    if char in "aeiou":
       print(char)