#1. Given a string of odd length greater than 7, return a new string made of the middle three characters
#of a given String
#Given:


#str1 = "RakeshzipPetabb"
#Output
#zip
#str2 = "JazzbonAyxx"
#Output
#bon

str1 = "RakeshzipPetabb"
str_a =str1[6:9]
print(str_a)

str2 = "JazzbonAyxx"
str_b =str2[4:7]
print(str_b)

#str1 = "RakeshzipPetabb"
#middle_index = len(str) // 2
#print(str[middle_index -1], str[middle_index],str[middle_index+1])
#print(str[middle_index-1]) : (middle_index+2)])

