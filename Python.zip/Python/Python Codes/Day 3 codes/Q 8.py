#8. Given a string in format Emp_name:Emp_id
#If emp_is is perfect square -- > Print only vowels from emp_name
#Else if emp_id is prime -- > print alternate characters from emp_name
#Else if emp_id is odd -- > print sum of ascii values of characters in emp_name
#Else print None

s1 = input("Enter emp_name:emp_id : ") #abc : 10
l1 = s1.split(":")  #['abc' , '10']
emp_name = l1[0]
emp_id = int(l1[1])

#take a no and check if it is perfect square
num = 64
pf_sq = 0
for n in range(1, num):
    if n**2 == num:
        print("perfect square")
        break
    if pf_sq == 1:
        print(pf_sq)

#vowel 
s1 = s1.lower()
for char in s1:
    if char in "aeiou":
       print(char)




   

