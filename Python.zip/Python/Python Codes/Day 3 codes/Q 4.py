#4. Given an input string with the combination of the lower and upper case arrange characters 
# in such a way that all lowercase letters should come first.

s1 = "AhJUra"
middle_1 = len(s1)//2
print(s1[1] + s1[4] + s1[5] + s1[0] + s1[2] + s1[3])






