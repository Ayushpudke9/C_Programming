#2. Given two strings, s1 and s2, create a new string by appending s2 in the middle of s1
#Given:
#AuKellylt


s1 = "Ault"
s2 = "Kelly" 
middle_1 = len(s1)//2
print(s1[:middle_1] + s2 + s1[middle_1:])

#3. two strings, s1, and s2 return a new string made of the first, middle, and last characters each input
#string
#Given:
#Expected Output:
#AJrpan
s1 = "America"
s2 = "Japan"

middle_1 = len(s1)//2
middle_2 = len(s2)//2
print(s1[0] + s2[0] +  s1[middle_1] + s2[middle_2] + s1[-1] + s2[-1])



