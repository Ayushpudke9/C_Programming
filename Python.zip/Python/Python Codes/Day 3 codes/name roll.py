#Q3. WAP to take following from user, 
#roll no : should be int : store in a variable
#percentage marks : should be float: store in a variable
#Any complex number : should be a complex number : store in a variable
#name of student: should be a string : store in a variable


roll_no = int(input("Enter roll number : "))  
percentage = float(input("Enter percentage marks : "))
complex_num = complex(input("Enter any complex number : ")) 
name = input("Enter student name: ")  

print("Roll Number:", roll_no)
print("Percentage Marks:", percentage)
print("Complex Number:", complex_num)
print("Student Name:", name)

#Q4. WAP to convert given integer to binary, hex and octal format

num = int(input("Enter a num: "))

binary = bin(num)  
hex = hex(num) 
octal = oct(num)  

print("Binary:", binary)
print("Hexadecimal:", hex)
print("Octal:", oct)