#menu driven program
#step 1: show a Menu
#step 2: ask user choice
#step 3: use match and case to execute only
#given option


#wap for a restro

print("menu : 1. misal 2. pizza 3. momo 4. noodles 5. dosa")
choice = int(input("enter your choice"))
print(choice)
match(choice):
  case 1:
    print("misal is selected! Rs 100")
  case 2:
    print("pizza is selected! Rs 120")
  case 3:
    print("momo is selected! Rs 60")
  case 4:
    print("noodles is selected! Rs 90")
  case 5:
    print("dosa is selected! Rs 50")
  case _:
    print("item not available")
