#Import math library and print the gcd, lcm of two numbers.

import math
num1 = int(input("enter number 1 :"))
num2 = int(input("enter number 2 :"))

gcd = math.gcd(num1, num2)
lcm = (num1 * num2) // gcd

print("Gcd of two no is :", gcd)
print("lcm of two no is :", lcm)

