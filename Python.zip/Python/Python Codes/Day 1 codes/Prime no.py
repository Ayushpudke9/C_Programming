num = int(input("enter a num :"))
if (num%2==0):
  print("non-prime")
else:
  print("prime")


num = int(input("enter a number :"))

n=2
while n<num:
  if num%n == 0:
    print("non-prime")
    break

else:
    print("prime")
    n=n+1