# A student will not be allowed to sit in exam if his/her attendence is less than 75%.

class_held = int(input("No of classes held :"))
class_attended = int(input("No of classes attended :"))

attendance_percent = (class_held / class_attended) * 100

if(attendance_percent >= 75):
    print("Not allowed to sit in exam")
else:
    print("Allowed to sit in exam")
