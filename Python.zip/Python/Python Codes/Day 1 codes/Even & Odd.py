num = int(input("enter a number :"))

if (num%2==0):
  print("even no")
elif(num%1==0):
  print("odd no")
else:
  print("invalid")


num = int(input("enter a number"))

if num % 5 == 0 and num % 11 == 0:
    print("num is divisible by both 5 and 11.")
else:
    print("num is NOT divisible by both 5 and 11.")
