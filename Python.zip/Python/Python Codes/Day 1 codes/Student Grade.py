no = int(input("enter a number :"))
print(no)

if(no<25):
  print("F Grade")
elif(no>25) and (no<45):
  print("Grade E")
elif(no>45) and (no<50):
  print("Grade D")
elif(no>50) and (no<60):
  print("Grade C")
elif(no>60) and (no<80):
  print("Grade B")
elif(no>80):
  print("Grade A")
else:
  print("Invalid")
