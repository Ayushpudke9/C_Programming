print("Hello World!")

import math
print(math.factorial(4))
print(math.sin(90))