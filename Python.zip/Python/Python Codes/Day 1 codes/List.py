# Write a for loop which run 5 times and ask 5 numbers from user and stores all 5 numbers in one list

l1=[]
for i in range(5):
    num = int(input("enter the number :"))
    l1.append(num)

print(l1)

print("print using for loop")
for idx in range(len(l1)):
    print(l1[idx])


print("print using another for loop")
for e in l1:   #e will ahve one element at a time
    print(e)