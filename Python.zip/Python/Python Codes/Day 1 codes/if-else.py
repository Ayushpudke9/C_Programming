no = int(input("enter your roll no :"))
print(no)
if (no>0) and (no<40):
    print("Valid")
else:
    print("Invalid")


no = int(input("enter no :"))
print(no)
if (no<50):
    print("Less")
elif (no>50) and (no<100):
    print("in between")
else:
    print("greater")


i=0
while i<5:
  print("hello")
  i=i+1
  