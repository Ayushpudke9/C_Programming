"*"
"**"
"***"
"****"
"*****"


for i in range(5):
    print("*" * (i+1))

# "*****"
# "****"
# "***"
# "**"
# "*"
# for n in range(5, 0, -1):
#     print("*" * (n))

# for n in range(1, 8, 2):
#     print("*" * (n))

# """
#     *
#   * * *
# * * * * *
# """
# #n_spaces = 2
# #for n_stars in range(1,6,2):
# #    print(" " * n_spaces + "*" * n_stars)
# #    n_spaces = n_spaces - 1

# """
#     *
#   * * *
# * * * * *

#   * * *
#     *
# """

# n_spaces = 0
# for n_stars in range(1,3,2):
#     print(" " * n_spaces + "*" * n_stars)
#     n_spaces = n_spaces - 1

  






