n = int(input("enter no of lines :"))
n_spaces = n//2
for n_stars in range(1,n+1,2):
    print(" " * n_spaces + "*" * n_stars)
    n_spaces = n_spaces - 1

n_spaces = n//2
for n_stars in range(n//2+1,0,-2):
    print(" " * n_spaces + "*" * n_stars)
    n_spaces = n_spaces - 1