# 5. Take a sentence as input from user. Every word is seperated by space. 
# a. Create a word_count dictionary which will have unique words and their count. 

# b. create suffix_count dictionary which will contain count of words ending with 's', 'es', 'ed', 'y', 'en' , etc.

# c. create dictionary word_length_count which will store length of word and count.
# Ex. 
# input_sent= 'CDAC is in Pune'
# There are 2 words of length 4 and 2 words of length 2 so,
# word_length_count = {2:2, 4:2}


s = input("Enter a sentence: ")
words = s.split()

word_count = {}
for word in words:
    word_count[word] = word_count.get(word, 0) + 1


suffix_list = ['s', 'es', 'ed', 'y', 'en']
suffix_count = {}
for word in words:
    for suffix in suffix_list:
        if word.endswith(suffix):
            suffix_count[suffix] = suffix_count.get(suffix, 0) + 1


word_length = {}
for word in words:
    length = len(word)
    word_length[length] = word_length.get(length, 0) + 1

print(word_count)
print(suffix_count)
print(word_length)

