#3. Write a menu driven program to practice Dictionary functions.

d = {}

while True:
    print("Dictionary Operations Menu")
    print("1. Add key-value pair")
    print("2. Update value for a key")
    print("3. Delete key")
    print("4. Search Key")
    print("5. Check if key exists")
    print("6. Exit")

    choice = int(input("Enter your choice: "))

    if choice == 1:
        key = input("Enter key: ")
        value = input("Enter value: ")
        d[key] = value
        print("Added")

    elif choice == 2:
        key = input("Enter key to update: ")
        if key in d:
            value = input("Enter new value: ")
            d[key] = value
            print("Updated")
        else:
            print("Key not found!")

    elif choice == 3:
        key = input("Enter key to delete: ")
        if key in d:
            del d[]
            print("Deleted")
        else:
            print("Key not found!")
            
    elif choice == 4:
        print("Current Dictionary:", d)

    elif choice == 5:
        key = input("Enter key to check: ")
        if key in d:
            print(d[key])
        else:
            print("Key not found!")

    elif choice == 6:
        print("exit")
        break
