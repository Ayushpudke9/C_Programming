#2. Given a dictionary of students and their favourite colours:
#people={'Arham':'Blue','Lisa':'Yellow',''Vinod:'Purple','Jenny':'Pink'}
#a. Find out how many students are in the list
#b. Change Lisa’s favourite colour
#c. Remove 'Jenny' and her favourite colour

people={'Arham':'Blue','Lisa':'Yellow','Vinod':'Purple','Jenny':'Pink'}
num_students = len(people)
print(num_students)

people['Lisa'] = 'Green'  
print()

people.pop('Jenny')
print(people)   


#4. Sort and print students and their favourite colours alphabetically by name

students_colors = {"Anita": "Blue", "Rohan": "Red", "Maya": "Green", "Vikas": "Yellow"}

sort = dict(sorted(students_colors.items()))

for name, color in sort.items():
    print(f"{name}: {color}")
    