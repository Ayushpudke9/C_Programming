# 7 Take two integer values in a & b. Swap their values using tuple, using temparary variable and 
# without tuple and without temparary variable.

a=10
b=23

print("Before Swap")
print(a)
print(b)

#syntax 1

a, b = b, a

print("After Swap")
print(a)
print(b)

#syntax 2

print("Before Swap")
print(a)
print(b)

temp = a
a = b
b = temp

print("After Swap")
print(a)
print(b)