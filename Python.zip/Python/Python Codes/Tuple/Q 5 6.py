#5. Copy element 44 and 55 from the following tuple into a new tuple

tuple1 = (11, 22, 33, 44, 55, 66)
tuple2 = tuple1[3:5]
print(tuple2)

#6. Modify the first item (22) of a list inside a following tuple to 200

tuple1 = (11, [22, 33], 44, 55)
tuple1[1][0] = 200
print(tuple1)