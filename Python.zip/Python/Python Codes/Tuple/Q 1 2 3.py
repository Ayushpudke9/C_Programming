#1. Reverse the following tuple

tuple = (10, 20, 30, 40, 50,60)
reverse_tuple = tuple[::-1]
print(tuple)

#2. display value 20 from the following tuple

aTuple = ("Orange", [10, 20, 30], (5, 15, 25))
print(aTuple[1][1])

#3. Unpack the following tuple into 4 variables
aTuple = (10, 20, 30, 40)
