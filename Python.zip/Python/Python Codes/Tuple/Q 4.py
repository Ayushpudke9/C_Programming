#swap the following tuple

tuple1 = (11, 22)
tuple2 = (99, 88)

print("Before Swap")
print(tuple1)
print(tuple2)

#syntax 1
temp = tuple1 
tuple1 = tuple2
tuple2 = temp

#syntax 2 
#tuple1, tuple2 = tuple2, tuple1

print("After Swap")
print(tuple1)
print(tuple2)

#print(tuple1, tuple2)