#4. set of all elements in either A or B, but not both
# {20, 70, 10, 60}

set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}

new_set=set1 ^ set2
print(new_set)


#5. Update set1 by adding items from set2, except common items

set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}

set1 = set1 ^ set2
print(set1)

#6. Take a sentence as input from user. 
#Every word is seperated by space. Print all unique words from the sentence.

s1 = input("enter a sentence :")
words = s1.split()
unique_words = set(words)
print(unique_words)

