#1. Add a list of elements to a given set

sampleSet = {"Yellow", "Orange", "Black"}
sampleList = ["Blue", "Green", "Red","Yellow","orange"]

sampleSet.update(sampleList)  

print(sampleSet)

#2 update set 1 by adding items from set2, except common items 

set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}

set1 = set1 ^ set2     #set1 ^= set2    #symmetric difference
print(set1)

#3. Generate a new set with all items from both sets by removing numbers which are in both sets.
# Output{70, 10, 20, 60,25,100} 

set1 = {10, 20, 30, 40, 50, 25}
set2 = {30, 40, 50, 60, 70, 100}

new_set = set1 ^ set2
print(new_set)
