#6. Remove empty strings from the list of strings
l1 = ["Ashish", "", "Atharva", "Amit", "", "Revati"]
l1.remove("")
l1.remove("")
print(l1)


#7. Add item 7000 after 6000 in the following Python List

l1 = [10, 20, [300, 400, [5000, 6000], 500], 30, 40]
l1[2][2].insert(2,7000)
print(l1)  

#8. Given a nested list extend it by adding the sub list ["h", "i", "j"] in such a way that 
# it will look like the following list

list1 = ["a", "b", ["c", ["d", "e", ["f", "g"], "k"], "l"], "m", "n"]
#Sub List to be added = ["h", "i", "j"]

list1 = ["a", "b", ["c", ["d", "e", ["f", "g"], "k"], "l"], "m", "n"]
subList = ["h", "i", "j"]
list1[2][1][2].extend(subList)
print(list1)



