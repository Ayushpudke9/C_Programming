#4. Print two lists in the following order

l1 = [5, 6,7]
l2 = [0, 1]

for i in range(len(l1)):
    for j in range(len(l2)):
        print(str(l1[i]) + str(l2[j]))
        

