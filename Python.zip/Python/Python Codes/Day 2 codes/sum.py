#l1=[10,20,30,40,50,60]
#l2=[e*e for e in l1]
#print(l2)


#l1=[10,34,23,56,78]
#total=0
#for idx in range(len(l1)):
    #total=total+l1[idx]
#print(total)


l1=[10,34,23,56,78]
mul=1
for idx in range(len(l1)):
    mul=mul*l1[idx] 
print(mul)


#wap take a list find the smallest number in list and find highest no in list

l1=[10,5,2,7,9,55,1,43]
min_num = l1[0]
for e in l1:
    if e < min_num:
        min_num = e
print(min_num)


l1=[10,5,2,7,9,55,1,43]
max_num = l1[0]
for e in l1:
    if e > max_num:
        max_num = e
print(max_num)