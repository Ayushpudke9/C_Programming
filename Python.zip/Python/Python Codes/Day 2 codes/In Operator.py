# In Operator

l1=[10,20,34,23,67,89]
num=int(input("enter the no to be searched in l1 :"))
if num in l1:
    print(num, " is present in l1")
else:
    print(num, " is not present in l1")
    
# l1 * 2  or  2 * l1  ...list will be repeated    

#wap to remove duplicates from a list

l1 = [10, 20, 34, 10, 23, 67, 89, 23, 34, 99]
#remove duplicate elements and put in new list 
#new list should not have duplicate elements

l2=[]
for e in l1:
    #check if it is present in l2
    if e in l2:
        pass
    else:
        l2.append(e)
print(l2)


    
