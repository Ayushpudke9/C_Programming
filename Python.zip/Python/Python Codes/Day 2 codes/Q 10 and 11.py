
#10. Given a Python list, remove all occurrence of 20 from the list

l1 = [5, 20, 15, 20, 25, 50, 20]
new_list = []
for e in l1:
    if e !=20:
        new_list.append(e)
print(new_list)

#another way
list1 = [5, 20, 15, 20, 25, 50, 20]
list1.remove(20)
list1.remove(20)
list1.remove(20)
print(list1)


#11. Take a number as input from user. 
#Print maximum and minimum integer which can be generated using all the digits in the input number
#Ex. Input 3421   : o/p max: 4321, min 1234
#Input 7789    : o/p max: 9776   min 6779

#Take a number as input from user and print all its digit separately

num = int(input("enter a number :"))

digits = []
while num !=0:
    d = num%10
    digits.append(d)
    num = num//10
print(digits[::-1])

#num_str = input("enter a number :")
#digits=list(num_str)