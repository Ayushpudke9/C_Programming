#Q15. WAP to create simple calculator in python.
#Take two numbers from user and give following options
#a. add b. subtract c. divide d. multiply e. integer division f. mod operation 
#g. check if both numbers are same  h. power operation i. square root of both numbers  j. log of both numbers
#k. gcd (find the  the greatest common divisor of the two integers) l. lcm (least common multiple)
#(Hint: Use inbuilt functions)

import math

num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))

print("Choose an operation:")
print("a. Add")
print("b. Subtract")
print("c. Divide")
print("d. Multiply")
print("e. Integer Division")
print("f. Modulo")
print("g. Check if both numbers are same")
print("h. Power")

choice = input("Enter your choice: ")

#choose operation
if choice == "a":
    print("Result:", num1 + num2)
elif choice == "b":
    print("Result:", num1 - num2)
elif choice == "c":
    print("Result:", num1/num2 if num2 != 0 else "Cannot divide by zero")
elif choice == "d":
    print("Result:", num1 * num2)
elif choice == "e":
    print("Result:", num1 // num2 if num2 != 0 else "Cannot divide by zero")
elif choice == "f":
    print("Result:", num1 % num2 if num2 != 0 else "Cannot find remainder with zero")
elif choice == "g":
    print("Both numbers are same" if num1 == num2 else "Numbers are different")
elif choice == "h":
    print("Result:", num1 ** num2)
else:
    print("Invalid choice")
