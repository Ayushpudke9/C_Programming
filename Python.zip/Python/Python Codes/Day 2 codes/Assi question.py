#a.
l1 = [ 0 , 1]
x= l1[0]
x, l1[x] = 1, 300
print(l1)

#b.
comp = [1, 2, ('aa', 'ab')]   < [1, 2, ('abc', 'a'), 4]
print(comp)