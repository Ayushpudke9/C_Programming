#wap to append 200 to l1
#insert 700 at index 3
#remove 5
#print the list

l1=[100,5,7,10,50]
l1.append(200)

l1.insert(3,700)

l1.remove(5)

#update index 4 to 1000
l1[4]=1000
print(l1) 