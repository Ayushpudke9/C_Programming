# take a list and delete the element at index 3 and check length of the list after deletion

l1 = [ 35, 65, 76, 32, 49]

del l1[3]

print(l1)

print(len(l1))
     