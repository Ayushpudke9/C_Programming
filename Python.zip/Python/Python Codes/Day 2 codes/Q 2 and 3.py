#2. take a list 'l1' of even nos between 150 to 250. Print its length.
#Then create another list 'l2' using 'l1', containing only nos divisible by 4 from 'l1'.

l1 = []
for i in range(150, 251):  
    if i % 2 == 0:  
        l1.append(i)  

print("Length of l1:", len(l1))  

l2 = []
for i in l1:  
    if i % 4 == 0:  
        l2.append(i)  

print("List l2:", l2)  


#3. Given a Python list of numbers. Turn every item of a list into its square root

import math
aList = [1, 4, 9, 16, 25, 36, 49] 
sqrt_list = [int(math.sqrt(num)) for num in aList]  
print(sqrt_list)  



